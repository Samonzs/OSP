#include<stdio.h>
#include<stdint.h>
#include"bits.h"


int main(int ac, char **av)
{
    uint8_t val = 200;

    print_bits(val);

    return 0;
}
